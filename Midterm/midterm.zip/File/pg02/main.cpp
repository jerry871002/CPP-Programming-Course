#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

class Date
{
public:
    Date();
    void print();
    void setDate(string);
    int getYear();
    
private:
    int month;
    int day;
    int year;
};

class Profile
{
public:
    Profile();
    Profile(string, string, char);
    Profile(string, string, char, string);
    void setAge();
    void setID();
    void print();
private:
    string   firstName;
    string   lastName;
    char    gender;
    Date    birthday;
    int     age;
    int     id;
};

int main()
{
    
    srand(time(NULL));
    
    Profile person1;
    person1.print();
    
    Profile person2("Charles", "Wen", 'M');
    person2.print();
    
    Profile person3("Shohei", "Ohtani", 'M', "19940705");
    person3.print();
    
    Profile person4("Aragaki", "Yui", 'F', "19880611");
    person4.print();
    
    Profile person5("Ashida", "Mana", 'F', "20040623");
    person5.print();
    
    return 0;
}